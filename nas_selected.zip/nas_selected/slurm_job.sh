#!/bin/bash
#SBATCH --job-name=nas                       
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --partition=compute
#SBATCH --gres=gpu:1
#SBATCH --mem=122536
#SBATCH --cpus-per-task=32                                                                                                                  


source .venv_nas/bin/activate


python3.8 a2c_vqae_dqnet_position_sep_advantange_latent.py
