#!/bin/bash
#SBATCH --job-name=deep_embeddings  
#SBATCH --output=slurm-%j.out                      
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --partition=compute
#SBATCH --gres=gpu:1
#SBATCH --mem=122536
#SBATCH --cpus-per-task=32                                                                                                                  


python3 dqnet_pl_deep_embeddings.py
