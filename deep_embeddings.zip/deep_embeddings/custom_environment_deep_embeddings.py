import gym
from gym import spaces
import numpy as np
import string
import tensorflow as tf
from tensorflow.keras.layers import Dense, Input
from tensorflow.keras.models import Model
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

from keras.layers import Input, Conv1D, MaxPooling1D, AveragePooling1D, Flatten, Dense, concatenate, Embedding
from keras.models import Model
from keras.callbacks import ModelCheckpoint

class TextEmbeddingEnvironment():
    def __init__(self, sequence_length, embedding_dim, alphabet_size, num_classes):

        self.sequence_length = sequence_length
        self.embedding_dim = embedding_dim
        self.alphabet_size = alphabet_size

        self.num_classes = num_classes

        # # Action space: The action is the adjustment to the internal state (embedding)
        # self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(self.embedding_dim,), dtype=np.float32)

        # # State space: The state is the current embedding
        # self.observation_space = spaces.Box(low=-1.0, high=1.0, shape=(self.embedding_dim,), dtype=np.float32)

        # Internal state (embedding) of the environment
        self.embedding = np.zeros((1, self.embedding_dim))

        self.x_data = None
        self.y_data = None


        self.classifier_model = self.define_classifier_network()

        #training parameters classifier network
        self.epochs = 10


        self.checkpoint_filepath = 'model_checkpoint.h5'
        self.model_checkpoint_callback = ModelCheckpoint(
            filepath=self.checkpoint_filepath,
            save_weights_only=True,
            monitor='val_loss',
            mode='min',
            save_best_only=True
        )
        self.first_run = True

        self.embedding_wieghts = None


    # def reset(self):
    #     # Reset the internal state (embedding) to zeros
    #     self.embedding = np.zeros((1, self.embedding_dim))
    #     return self.embedding.copy()

    def step(self, embedding_prediction):

        if not self.first_run:
            #take the weights form last iteration and fit the model
            self.classifier_model.load_weights(self.checkpoint_filepath)

        self.classifier_model.layers[1].set_weights(self.embedding_wieghts)

        history = self.classifier_model.fit(embedding_prediction, self.y_data, 
            epochs=self.epochs,
            batch_size=32,
            verbose=1,
            validation_split=0.1, 
            callbacks=[self.model_checkpoint_callback]
        )

        if self.first_run:
            self.classifier_model.save_weights(self.checkpoint_filepath)
            self.first_run = False
        
        reward = int(np.mean(history.history['accuracy'])*100)

        done = False

        return embedding_prediction, reward, done, {}


        # # Clip the action to stay within the valid range
        # action = np.clip(action, -1.0, 1.0)

        # # Update the embedding using the action
        # self.embedding += action

        # # Clip the embedding to stay within the valid range
        # self.embedding = np.clip(self.embedding, -1.0, 1.0)

        # # Generate a random text sequence
        # text_sequence = np.random.choice(list(self.char_alphabet), size=self.sequence_length)

        # # Encode the text sequence using the current embedding
        # encoded_sequence = self.encode_sequence(text_sequence)

        # # Calculate a reward based on a simple text classification task
        # reward = self.calculate_reward(encoded_sequence)

        # # Return the new state (embedding), reward, and a flag indicating the end of the episode
        # return self.embedding.copy(), reward, False, {}

    

    def inception_module(self, x, filters):
        conv1x1 = Conv1D(filters[0], 1, padding='same', activation='relu')(x)
        
        conv3x3 = Conv1D(filters[1], 3, padding='same', activation='relu')(x)
        
        conv5x5 = Conv1D(filters[2], 5, padding='same', activation='relu')(x)
        
        maxpool = MaxPooling1D(3, strides=1, padding='same')(x)
        maxpool_conv1x1 = Conv1D(filters[3], 1, padding='same', activation='relu')(maxpool)
        
        inception_block = concatenate([conv1x1, conv3x3, conv5x5, maxpool_conv1x1], axis=-1)
        
        return inception_block


    def define_classifier_network(self):

        # Define GoogLeNet model
        input_layer = Input(shape=(self.sequence_length))  # Example input shape for an image

        embeddings = Embedding(input_dim=self.sequence_length ,output_dim=self.embedding_dim, trainable=False)(input_layer)

        # Initial Convolution layers
        x = Conv1D(64, 7, strides=2, padding='same', activation='relu')(embeddings)
        x = MaxPooling1D(3, strides=2, padding='same')(x)

        # Inception modules
        x = self.inception_module(x, [64, 128, 32, 32])
        x = self.inception_module(x, [128, 192, 96, 64])
        x = MaxPooling1D(3, strides=2, padding='same')(x)

        # Add more Inception modules or additional layers as needed

        # Fully connected layers
        x = Flatten()(x)
        x = Dense(512, activation='relu')(x)
        output_layer = Dense(self.num_classes, activation='softmax')(x)

        # Create and compile the model
        googlenet_model = Model(inputs=input_layer, outputs=output_layer)
        googlenet_model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

        # Display the model architecture
        #googlenet_model.summary()
        return googlenet_model







